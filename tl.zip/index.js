// Entry point for BumbooHost / generic Node.js hosting.
// Keeps the actual bot source in src/bot.js.
require('./src/bot.js');
